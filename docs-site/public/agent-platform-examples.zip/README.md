# Agent Platform 연동 예제 코드

## 파일 목록

| 파일 | 설명 |
|---|---|
| `agent_platform_auth.py` | OIDC 인증 SDK (프로젝트에 복사해서 사용) |
| `example_openai.py` | OpenAI SDK 예제 |
| `example_langchain.py` | LangChain 예제 |
| `example_adk.py` | Google ADK 예제 (1.x / 2.0 공용) |
| `example_fastapi.py` | FastAPI 웹 서비스 예제 |

## 사용법

1. `a2g.samsungds.net`를 실제 Agent Platform 서버 IP로 치환
2. `agent_platform_auth.py`를 프로젝트 디렉토리에 복사
3. 예제 코드 실행

```bash
# 서버 IP 일괄 치환
sed -i 's/a2g.samsungds.net/172.26.110.192/g' *.py

# 실행
python example_openai.py
```
