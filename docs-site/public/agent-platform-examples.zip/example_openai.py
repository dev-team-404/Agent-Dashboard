"""OpenAI SDK 예제 — setup_auth() 한 번이면 user 자동 주입"""
from agent_platform_auth import setup_auth
setup_auth(gateway_url="http://a2g.samsungds.net:8090")

from openai import OpenAI
client = OpenAI(base_url="http://a2g.samsungds.net:8090/v1", api_key="sk-placeholder",
                default_headers={"x-service-id": "my-service"})

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "안녕하세요"}],
    # user= 안 넣어도 자동 주입됨
)
print(response.choices[0].message.content)
