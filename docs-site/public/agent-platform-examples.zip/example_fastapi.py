"""FastAPI 웹 서비스 예제 — 요청별 사용자 자동 전환"""
from fastapi import FastAPI, Request
from agent_platform_auth import setup_auth, set_user
from langchain_openai import ChatOpenAI

app = FastAPI()
setup_auth(gateway_url="https://a2g.samsungds.net:9050")

llm = ChatOpenAI(model="gpt-4o", base_url="http://a2g.samsungds.net:8090/v1", api_key="sk-placeholder",
                 default_headers={"x-service-id": "my-service"})

@app.post("/chat")
async def chat(request: Request):
    user = request.headers.get("x-user-id", "anonymous")
    set_user(user)  # 이 요청의 사용자 설정 → LLM 호출 시 자동 주입
    result = llm.invoke(request.query_params.get("q", "안녕"))
    return {"response": result.content}
