"""Google ADK 예제 (1.x / 2.0 공용) — setup_auth() 한 번이면 user 자동 주입"""
from agent_platform_auth import setup_auth
setup_auth(gateway_url="http://a2g.samsungds.net:8090")

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

agent = Agent(name="my_agent", model="openai/gpt-4o", instruction="친절한 AI 어시스턴트")
runner = Runner(agent=agent, app_name="my_app", session_service=InMemorySessionService())
