"""LangChain 예제 — setup_auth() 한 번이면 user 자동 주입"""
from agent_platform_auth import setup_auth
setup_auth(gateway_url="http://a2g.samsungds.net:8090")

from langchain_openai import ChatOpenAI
llm = ChatOpenAI(
    model="gpt-4o",
    base_url="http://a2g.samsungds.net:8090/v1",
    api_key="sk-placeholder",
    default_headers={"x-service-id": "my-service"},
)
print(llm.invoke("안녕하세요").content)
